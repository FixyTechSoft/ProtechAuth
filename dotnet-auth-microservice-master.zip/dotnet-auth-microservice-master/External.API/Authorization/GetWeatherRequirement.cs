﻿using Microsoft.AspNetCore.Authorization;

namespace External.API.Authorization
{
    public class GetWeatherRequirement : IAuthorizationRequirement
    {
    }
}
