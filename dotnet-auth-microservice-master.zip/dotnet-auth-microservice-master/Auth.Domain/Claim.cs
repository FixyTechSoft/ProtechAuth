﻿namespace Auth.Domain
{
    public class Claim
    {
        public string Type { get; set; }
        public string Value { get; set; }
    }
}
