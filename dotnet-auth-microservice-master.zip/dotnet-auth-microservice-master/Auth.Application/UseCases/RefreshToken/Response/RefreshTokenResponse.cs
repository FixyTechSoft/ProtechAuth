﻿namespace Auth.Application.UseCases.RefreshToken.Response
{
    public abstract class RefreshTokenResponse : UseCases.Response
    {
    }
}
