﻿namespace Auth.Application.UseCases.CreateUser.Request
{
    public class Claim
    {
        public string Type { get; set; }
        public string Value { get; set; }
    }
}
