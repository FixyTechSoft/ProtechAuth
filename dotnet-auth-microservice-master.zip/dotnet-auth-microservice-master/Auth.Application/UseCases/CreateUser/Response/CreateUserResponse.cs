﻿namespace Auth.Application.UseCases.CreateUser.Response
{
    public abstract class CreateUserResponse : UseCases.Response
    {
    }
}
