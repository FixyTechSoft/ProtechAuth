﻿namespace Auth.Application.UseCases
{
    public abstract class Response
    {
    }
}
