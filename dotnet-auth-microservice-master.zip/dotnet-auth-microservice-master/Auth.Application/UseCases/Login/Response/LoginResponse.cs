﻿namespace Auth.Application.UseCases.Login.Response
{
    public abstract class LoginResponse : UseCases.Response
    {
    }
}
