﻿namespace Auth.Application.UseCases.SignOut.Response
{
    public class SignOutSuccessResponse : SignOutResponse
    {
        public string Message { get; set; }
    }
}
