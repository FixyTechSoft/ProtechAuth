﻿namespace Auth.Application.UseCases.SignOut.Response
{
    public abstract class SignOutResponse : UseCases.Response
    {
    }
}
